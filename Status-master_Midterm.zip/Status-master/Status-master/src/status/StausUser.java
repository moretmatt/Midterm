package status;

public class StausUser {
   private StatusType userStatus;
   public StausUser(StatusType userStatus){
       this.userStatus = userStatus;
   }
    public StatusType getUserStatus(){
        return userStatus;
    }
    public void setUserStatus(StatusType userStatus){
        this.userStatus = userStatus;
    }
    public void showStatus(){
        System.out.println("User status is: " + userStatus);
    }
}
