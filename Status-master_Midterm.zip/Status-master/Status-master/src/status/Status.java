package status;

import java.util.Scanner;

public class Status {
    public static void main(String[] args){
        Status user1 = new Status(StatusType.COMPLETED);
        user1.showStatus();
    }
}